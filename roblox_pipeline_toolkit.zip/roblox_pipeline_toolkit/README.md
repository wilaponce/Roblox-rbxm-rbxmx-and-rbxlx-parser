# Roblox RBXLX / RBXM Repair, Merge & Open Cloud Pipeline

Modular CLI toolkit for Termux and Linux to repair corrupted Roblox XML schemas, convert binary `.rbxm` models to `.rbxmx`, merge systems into `.rbxlx` places, audit/unwrap Lua scripts, and publish via the Roblox Open Cloud Places API.

## Setup
```bash
chmod +x build.sh
./build.sh
```

## Run
```bash
./roblox_pipeline.sh
```
